<!-- add stylesheets and scripts !-->
<?php include "templates/head.php"; ?>

<div class="display-1">
    <div class="text-center img-border" style="background-color:beige; background:linear-gradient(transparent beige 100px, transparent beige 10px); opacity:0.8; width:70%; margin:auto; padding-top:100px;">
        <div class="text-success display-1">Holiday drinks!</div>
        <div class="text-success h3" style="width:70%; margin:auto;">Sorry, currently out of stock. Guess you can't prepare them today.</div>
        <img src="https://globalassets.starbucks.com/assets/15071d409817468097149cb77440b375.png" alt="Seasonal" width=800>
        <br><br>
    </div>
    <br>
</div>

<!-- add remaining scripts -->
<?php include "templates/footer.php"; ?>
